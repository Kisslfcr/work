FLASK_DEBUG=1 FLASK_APP=manage.py flask run --host=0.0.0.0  -p 3333 
